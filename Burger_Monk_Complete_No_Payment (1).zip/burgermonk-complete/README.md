# Burger Monk – QR Ordering & Admin System

Payment gateway intentionally excluded. Customers place orders and pay at the counter / in cash. This project includes a customer menu, cart, checkout, order ID, receipt, customer order tracking, admin login, order status management, product management and Netlify deployment configuration.

## Important: production setup

The app uses Supabase for shared customer/admin data. Without Supabase credentials it runs in local preview mode using browser storage; in that mode customer orders are NOT shared across devices and the demo admin login is not enabled.

### 1. Create Supabase project
1. Create a project at https://supabase.com.
2. Open SQL Editor and run `database/schema.sql`.
3. In Authentication > Users, create the cafe admin user with email and password.
4. Copy that user's UUID. In SQL Editor run:
   `insert into public.admin_users(user_id) values ('PASTE-USER-UUID-HERE');`
5. In Project Settings > API, copy Project URL and anon/public key.
6. Put both values in `config.js`. Never use the service_role key in browser code.

### 2. Deploy to Netlify
1. Upload the complete contents of this folder to a GitHub repository (keep folder structure).
2. Import the repository in Netlify.
3. Build command: leave blank. Publish directory: `.`
4. Deploy. Customer site: `/customer/` (root redirects there). Admin: `/admin/`.

### 3. QR codes
Use URLs such as `https://YOUR-DOMAIN.netlify.app/customer/?table=1` and print one per table. The table number is read automatically for dine-in orders.

### 4. Admin
Open `/admin/`, sign in using the Supabase Auth email/password, and make sure the user UUID is present in `admin_users`. Admin can update statuses: New, Confirmed, Preparing, Ready, Delivered or Rejected, and add products / toggle availability.

### 5. Payment behavior
No online payment gateway is connected. Checkout records payment method as Pay at Counter / Cash. The system must not be described as collecting or verifying online payments. Staff confirms payment at the cafe outside the website.

## Menu note
The initial menu is sample data pending confirmation against the outlet's current menu and prices. Update `customer/app.js` seed list for local preview, or edit `products` in Supabase after setup.

## Security notes
- Keep Supabase service_role key private; only anon/public key belongs in `config.js`.
- Admin access is controlled by Supabase Auth and `admin_users` table.
- Customer tracking uses a random UUID tracking code and an RPC that returns only the matching order's customer-facing fields.
- Review and test policies before production launch. Add rate limiting / CAPTCHA if public order spam becomes an issue.
