// Add your Supabase project URL and anon/public key here. Never put service_role keys in frontend files.
window.BM_CONFIG={SUPABASE_URL:'',SUPABASE_ANON_KEY:''};
